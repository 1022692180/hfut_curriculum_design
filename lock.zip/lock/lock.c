#include "stdio.h"
#define GPFCON              (*((volatile unsigned long *)0x7F0080A0))
#define GPFDAT              (*((volatile unsigned long *)0x7F0080A4))
#define GPKCON0     		(*((volatile unsigned long *)0x7F008800))
#define GPKDATA     		(*((volatile unsigned long *)0x7F008808))
#define GPNCON     			(*((volatile unsigned long *)0x7F008830))
#define GPNDAT     			(*((volatile unsigned long *)0x7F008834))

#define EINT0CON0  			(*((volatile unsigned long *)0x7F008900))
#define EINT0MASK  			(*((volatile unsigned long *)0x7F008920))
#define EINT0PEND  			(*((volatile unsigned long *)0x7F008924))
#define PRIORITY 	    	(*((volatile unsigned long *)0x7F008280))
#define SERVICE     		(*((volatile unsigned long *)0x7F008284))
#define SERVICEPEND 		(*((volatile unsigned long *)0x7F008288))
#define VIC0IRQSTATUS  		(*((volatile unsigned long *)0x71200000))
#define VIC0FIQSTATUS  		(*((volatile unsigned long *)0x71200004))
#define VIC0RAWINTR    		(*((volatile unsigned long *)0x71200008))
#define VIC0INTSELECT  		(*((volatile unsigned long *)0x7120000c))
#define VIC0INTENABLE  		(*((volatile unsigned long *)0x71200010))
#define VIC0INTENCLEAR 		(*((volatile unsigned long *)0x71200014))
#define VIC0PROTECTION 		(*((volatile unsigned long *)0x71200020))
#define VIC0SWPRIORITYMASK 	(*((volatile unsigned long *)0x71200024))
#define VIC0PRIORITYDAISY  	(*((volatile unsigned long *)0x71200028))
#define VIC0ADDRESS        	(*((volatile unsigned long *)0x71200f00))

#define		PWMTIMER_BASE			(0x7F006000)
#define		TCFG0    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x00)) )
#define		TCFG1    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x04)) )
#define		TCON      	( *((volatile unsigned long *)(PWMTIMER_BASE+0x08)) )
#define		TCNTB0    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x0C)) )
#define		TCMPB0    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x10)) )
#define		TCNT00    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x14)) )
#define		TCNTB1    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x18)) )
#define		TCMPB1    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x1C)) )
#define		TCNTO1    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x20)) )
#define		TCNTB2    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x24)) )
#define		TCMPB2    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x28)) )
#define		TCNTO2    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x2C)) )
#define		TCNTB3    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x30)) )
#define		TCMPB3    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x34)) )
#define		TCNTO3    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x38)) )
#define		TCNTB4    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x3C)) )
#define		TCNTO4    	( *((volatile unsigned long *)(PWMTIMER_BASE+0x40)) )
#define		TINT_CSTAT 	( *((volatile unsigned long *)(PWMTIMER_BASE+0x44)) )


typedef void (isr)(void);

//��ʱ���ж�
extern void asm_timer_irq();

extern int timer_status;

extern int wait;

extern void delay();

//���������Ƶ�����
int index = 0;

//������˸������
int info = 0;


//�жϳ�ʼ��
void irq_init(void)
{
	/* ���жϿ�������ʹ��timer0�ж� */
	VIC0INTENABLE |= (1 << 23);

	VIC0INTSELECT = 0;

	isr** isr_array = (isr**)(0x7120015C);

	isr_array[0] = (isr*)asm_timer_irq;
}

// ��ʼ��timer
void timer_init(unsigned long utimer, unsigned long uprescaler, unsigned long udivider, unsigned long utcntb, unsigned long utcmpb)
{

	unsigned long temp0;

	// ��ʱ��������ʱ�� = PCLK / ( {prescaler value + 1} ) / {divider value} = PCLK/(65+1)/16=62500hz

	//����Ԥ��Ƶϵ��Ϊ66
	temp0 = TCFG0;
	temp0 = (temp0 & (~(0xff00ff))) | (uprescaler << 0);
	TCFG0 = temp0;

	// 16��Ƶ
	temp0 = TCFG1;
	temp0 = (temp0 & (~(0xf << 4 * utimer)) & (~(1 << 20))) | (udivider << 4 * utimer);
	TCFG1 = temp0;

	// 1s = 62500hz
	TCNTB0 = utcntb;
	TCMPB0 = utcmpb;

	// �ֶ�����
	TCON |= 1 << 1;

	// ���ֶ�����λ
	TCON &= ~(1 << 1);

	// �Զ����غ�����timer0
    TCON |= (1 << 0)|(1 << 3);
       

	// ʹ��timer0�ж�
	temp0 = TINT_CSTAT;
	temp0 = (temp0 & (~(1 << (utimer)))) | (1 << (utimer));
	TINT_CSTAT = temp0;
}
	

//��ʱ��0���жϷ������
void do_irq(void)
{
	//����Ƕ̰�K3�����ǰ�K4���붨ʱ���жϣ��ĸ�LED�ư�1��ļ����LED1��ʼ˫��������ѭ����ʾ
	if (timer_status == 0) {
		if(!wait){
			index++;
			if (index == 1 ){
			//���õ�һ������
				GPKDATA = 0xef;
			}
			else if(index==2 || index==6){
				GPKDATA = 0xdf;
			}
			else if(index==3 || index==5){
				GPKDATA = 0xbf;
			}
			else if(index==4){
				GPKDATA = 0x7f;
			}
			else if(index==7){
				index=0;
			}
		}
	}
	//������������������붨ʱ���жϣ��ĸ�LED�ư�0.5��ļ��������˸�����ҷ�������������
	else if (timer_status == 1) {
		GPFDAT = 0x4000;
		if (info == 0) {
			GPKDATA = 0x00;
		}
		else if (info == 1) {
			GPKDATA = 0xf0;
			info = -1;
		}
		info++;
	}
    unsigned long uTmp;
	//��timer0���ж�״̬�Ĵ���
	uTmp = TINT_CSTAT;
	TINT_CSTAT = uTmp;
	VIC0ADDRESS = 0x0;
}
