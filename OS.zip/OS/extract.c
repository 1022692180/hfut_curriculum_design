#include "os.h"

int extractOffset(uint32_t logicalAddress) {
    // 提取页内偏移量（低 12 位）
    return logicalAddress & PAGE_OFFSET_MASK;
}

int extractPage(uint32_t logicalAddress){
    // 提取页号（高 20 位）
    return logicalAddress >> 12;
}