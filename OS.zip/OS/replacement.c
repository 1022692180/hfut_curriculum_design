#include "os.h"

// 置换算法要实现找到合适的物理块并把新的页面装入物理块
// 局部置换算法：根据页面序列（pageSequence）进行置换
void Local_Replace(Process *process, int pageNumber) {
    // 1. 获取要被置换的物理块（页面队列头部）
    int replacedPage = process->pageSequence[0]; // 获取队列头部的页面
    int replacedBlock = process->pageTable[replacedPage].frame_number; // 获取对应的物理块

    // 2. 将被置换出去的页面标记为无效
    process->pageTable[replacedPage].valid = false;
    process->pageTable[replacedPage].frame_number = -1;

    // 3. 更新页表：将新页面映射到置换得到的物理块
    process->pageTable[pageNumber].valid = true;
    process->pageTable[pageNumber].frame_number = replacedBlock;

    // 4. 维护 pageSequence：将新页面插入队列尾部，并将队列头部出队
    for (int i = 0; i < process->pageSequenceSize - 1; i++) {
        process->pageSequence[i] = process->pageSequence[i + 1]; // 队列整体前移
    }
    process->pageSequence[process->pageSequenceSize - 1] = pageNumber; // 新页面加入队尾
}

// 全局置换算法
void Global_Replace(Process* process, int pageNumber) {
    // 1. 找到要被置换的页面（全局队列头部）
    int replacedPage = page_queue[0]; // 获取队列头部的页面
    int replacedProcessID = pid_queue[0]; // 获取队列头部的进程ID

    // 2. 根据进程ID找到对应的进程
    for (int i = 0; i < process_size; i++) {
        if (process_queue[i]->processID == replacedProcessID) {
            // 3. 获取被置换页面对应的物理块
            int replacedBlock = process_queue[i]->pageTable[replacedPage].frame_number;

            // 4. 将被置换出去的页面标记为无效
            process_queue[i]->pageTable[replacedPage].valid = false;
            process_queue[i]->pageTable[replacedPage].frame_number = -1;

            // 5. 找到当前访问页面的进程
            for (int j = 0; j < process_size; j++) {
                if (process_queue[j]->processID == process->processID) {
                    // 6. 将新页面映射到置换得到的物理块
                    process_queue[j]->pageTable[pageNumber].valid = true;
                    process_queue[j]->pageTable[pageNumber].frame_number = replacedBlock;
                    break;
                }
            }
            // 7. 维护全局队列：将新页面插入队列尾部，并将队列头部出队
            for (int k = 0; k < queue_size - 1; k++) {
                page_queue[k] = page_queue[k + 1]; // 队列整体前移
                pid_queue[k] = pid_queue[k + 1]; // 队列整体前移
            }
            page_queue[queue_size - 1] = pageNumber; // 新页面加入队尾
            pid_queue[queue_size - 1] = process->processID; // 新进程ID加入队尾
            break;
        }
    }
}

void updateLRU(Process *process, int pageNumber) {
    // 更新页面序列：将访问的页面移动到队列尾部
    if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_LOCAL_REPLACEMENT || 
        ALLOCATION_STRATEGY == FIXED_ALLOCATION_LOCAL_REPLACEMENT) {
        // 局部置换策略：更新当前进程的页面序列
        for (int i = 0; i < process->pageSequenceSize; i++) {
            if (process->pageSequence[i] == pageNumber) {
                // 找到页面，将其移动到队列尾部
                for (int j = i; j < process->pageSequenceSize - 1; j++) {
                    process->pageSequence[j] = process->pageSequence[j + 1];
                }
                process->pageSequence[process->pageSequenceSize - 1] = pageNumber;
                break;
            }
        }
    }
    else if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT) {
        // 全局置换策略：更新全局页面访问队列
        for (int i = 0; i < queue_size; i++) {
            if (page_queue[i] == pageNumber && pid_queue[i] == process->processID) {
                // 找到页面，将其移动到队列尾部
                for (int j = i; j < queue_size - 1; j++) {
                    page_queue[j] = page_queue[j + 1];
                    pid_queue[j] = pid_queue[j + 1];
                }
                page_queue[queue_size - 1] = pageNumber;
                pid_queue[queue_size - 1] = process->processID;
                break;
            }
        }
    }
}