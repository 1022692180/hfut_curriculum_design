#include "os.h"

// 初始化物理块表：把内存空间分成和页面相同大小的物理块
void initPhysicalBlocks() {
    physicalBlocks = (PhysicalBlock *)malloc(TOTAL_PHYSICAL_BLOCKS * sizeof(PhysicalBlock));
    for (int i = 0; i < TOTAL_PHYSICAL_BLOCKS; i++) {
        physicalBlocks[i].blockNumber = i;
        physicalBlocks[i].startAddress = i * PHYSICAL_BLOCK_SIZE;
        physicalBlocks[i].isFree = true;
        physicalBlocks[i].processID = -1;
    }
}

// 释放分配的物理块表
void freePhysicalBlocks() {
    if (physicalBlocks != NULL) {
        free(physicalBlocks);
        physicalBlocks = NULL;
    }
}

// 为进程创建的时候分配一定数量的物理块
void allocatePhysicalBlocksForProcess(Process *process, int numBlocks) {
    int allocatedBlocks = 0; // 已分配的物理块数量

    // 尝试为进程分配物理块
    for (int i = 0; i < numBlocks; i++) {
        for (int j = 0; j < TOTAL_PHYSICAL_BLOCKS; j++) {
            if (physicalBlocks[j].processID < 0) {
                physicalBlocks[j].isFree = true;//分配给进程，但是还没有装入页面，因此仍然处于空闲状态
                physicalBlocks[j].processID = process -> processID;
                process->frameQueue[process->frameQueueRear] = j;
                // 尾指针指向最后一个物理块的下一个位置
                process->frameQueueRear = process->frameQueueRear + 1;
                allocatedBlocks++;
                break;
            }
        }
    }

    // 如果物理块不足，根据分配策略选择置换算法
    while (allocatedBlocks < numBlocks) {
        // 根据 ALLOCATION_STRATEGY 选择置换策略
        if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_LOCAL_REPLACEMENT || FIXED_ALLOCATION_LOCAL_REPLACEMENT) {
            // 局部置换策略，只会在已经分配给进程的物理块中进行置换
            Local_Replace(process, -1);
        }
        else if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT) {
            // 全局置换策略，会在所有物理块中进行置换
            Global_Replace(process, -1);
        }
    }
}

// 页面访问时为页面分配物理块的函数
void allocatePhysicalBlockForPage(Process *process, int pageNumber) {
    int frameNumber = -1;

    // 页面不在内存中，尝试从进程的物理块队列中找到一个空闲的物理块
    for (int i = 0; i < process->numFrames; i++) {
        if (physicalBlocks[process->frameQueue[i]].isFree) {
            frameNumber = process->frameQueue[i];
            break;
        }
    }

    // 如果没有空闲的物理块，执行置换算法
    if (frameNumber == -1) {
        // 根据 ALLOCATION_STRATEGY 选择置换策略
        if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_LOCAL_REPLACEMENT || ALLOCATION_STRATEGY == FIXED_ALLOCATION_LOCAL_REPLACEMENT) {
            // 局部置换策略
            Local_Replace(process, pageNumber);
        } else if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT) {
            // 全局置换策略
            Global_Replace(process, pageNumber);
        }
        
        // 增加缺页率
        process->pageFaults++;
    }

    else {
        // 还有空闲的物理块，需要把页面装入物理块并且更新页表，但是物理块队列不需要改变
        physicalBlocks[frameNumber].isFree = false; // 物理块已经装入页面

        process->pageTable[pageNumber].valid = true; // 已经装入内存
        process->pageTable[pageNumber].frame_number = frameNumber; // 页号与物理块号的对应

        // 插入页面到页面访问序列的队尾
        if (ALLOCATION_STRATEGY == FIXED_ALLOCATION_LOCAL_REPLACEMENT || ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_LOCAL_REPLACEMENT) {
            process->pageSequenceSize++;
            process->pageSequence[process->pageSequenceSize - 1] = pageNumber;
        }
        else if(ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT){
            page_queue[queue_size] = pageNumber;
            pid_queue[queue_size] = process->processID;
            queue_size++;
        }
    }
}
