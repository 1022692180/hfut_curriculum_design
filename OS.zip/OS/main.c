#include "os.h"

// 进程需要访问的逻辑地址列表
// 页号列表：0 1 2 3 0 1 4 2 1 2 3 4 5 1 2 0 3
// 固定分配局部置换FIFO算法：缺页次数 6
// 固定分配局部置换LRU算法：缺页次数 8
// 可变分配局部置换FIFO算法：缺页次数 5
// 可变分配局部置换LRU算法：缺页次数 7

uint32_t logic_address_sequence_1[] = {0x00000000, 0x00001400, 0x00002800, 0x00003C00};

uint32_t logic_address_sequence_2[] = {0x00000000, 0x00001400, 0x00002800, 0x00003C00, 0x00000FFF, 0x000017FF, 
                                     0x000043FF, 0x00002000, 0x00001324, 0x00002600, 0x00003E00, 0x00004FFF, 
                                     0x00005324, 0x00001342, 0x00002637, 0x00000C67, 0x000039B7};

int main() {
    // 初始化物理块表
    initPhysicalBlocks();

    // 初始化全局页面访问队列和进程ID队列
    initGlobalQueues();

    // 初始化进程队列
    initProcessQueue();

    //读取文件中的进程信息
    Process process_1;
    loadProcessInfoFromDisk(&process_1, "process_1.dat");

    // 创建一个进程，申请的内存大小为 16KB  一共分配 4 个物理块
    // createProcess(&process_1, 1, 16 * 1024); // 16KB = 16 * 1024 bytes

    // 打印进程信息
    printf("Process ID: %d\n", process_1.processID);
    printf("Initial Allocated Frames: %d\n", process_1.numFrames);

    // 进程分配的物理块全都装入了页面
    int total_accesses_1 = sizeof(logic_address_sequence_1) / sizeof(logic_address_sequence_1[0]);
    for (int i = 0; i < total_accesses_1; i++) {
        int pageNumber = extractPage(logic_address_sequence_1[i]);
        accessPage(&process_1, pageNumber);
    }

    printf("Lateset Allocated Frames: %d\n", process_1.numFrames);
    // 计算缺页率
    double page_fault_rate_1 = ((double)process_1.pageFaults / total_accesses_1) * 100.0;
    printf("Total Page Accesses: %d\n", total_accesses_1);
    printf("Total Page Faults: %d\n", process_1.pageFaults);
    printf("Page Fault Rate: %.2f%%\n", page_fault_rate_1);

    // 保存进程信息到磁盘
    saveProcessInfoToDisk(&process_1, "process_1.dat");
    
    Process process_2;
    createProcess(&process_2, 2, 16 * 1024); // 16KB = 16 * 1024 bytes

    // 打印进程信息
    printf("Process ID: %d\n", process_2.processID);
    printf("Initial Allocated Frames: %d\n", process_2.numFrames);

    // 进程分配的物理块全都装入了页面
    int total_accesses = sizeof(logic_address_sequence_2) / sizeof(logic_address_sequence_2[0]);
    for (int i = 0; i < total_accesses; i++) {
        int pageNumber = extractPage(logic_address_sequence_2[i]);
        accessPage(&process_2, pageNumber);
    }
    printf("Lateset Allocated Frames: %d\n", process_2.numFrames);

    // 计算缺页率
    double page_fault_rate = ((double)process_2.pageFaults / total_accesses) * 100.0;
    printf("Total Page Accesses: %d\n", total_accesses);
    printf("Total Page Faults: %d\n", process_2.pageFaults);
    printf("Page Fault Rate: %.2f%%\n", page_fault_rate);

    freeGlobalQueues();
    freeProcessQueue();
    freePhysicalBlocks();
    system("pause");

    return 0;
}