#include "os.h"

// 全局变量初始化
PhysicalBlock *physicalBlocks = NULL;

int *page_queue = NULL;
int *pid_queue = NULL;

int queue_size = 0;

Process *process_queue[MAX_PROCESS_SIZE];  // 定义全局变量

int process_size = 0;

int dynamicThreshold = 5;

// 初始化全局页面访问队列和进程ID队列
void initGlobalQueues() {
    page_queue = (int *)malloc(MAX_QUEUE_SIZE * sizeof(int));
    pid_queue = (int *)malloc(MAX_QUEUE_SIZE * sizeof(int));

    for (int i = 0; i < MAX_QUEUE_SIZE; i++) {
        page_queue[i] = -1; // 初始化为无效页面
        pid_queue[i] = -1;  // 初始化为无效进程ID
    }
}

// 释放全局页面访问队列和进程ID队列
void freeGlobalQueues() {
    if (page_queue != NULL) {
        free(page_queue);
        page_queue = NULL;
    }
    if (pid_queue != NULL) {
        free(pid_queue);
        pid_queue = NULL;
    }
}

// 初始化进程队列
void initProcessQueue() {
    for (int i = 0; i < MAX_PROCESS_SIZE; i++) {
        process_queue[i] = (Process *)malloc(sizeof(Process)); // 为每个指针分配内存
        process_queue[i]->processID = -1; // 初始化为无效进程ID
    }
}

// 释放进程队列
void freeProcessQueue() {
    
}

// 创建进程：进程号 进程申请的内存空间大小
void createProcess(Process* process, int processID, int requestedSize) {
    if (process_size > MAX_PROCESS_SIZE) {
        return;
    }

    process->processID = processID;

    process_queue[process_size] = process;
    process_size++; // 进程数量增加

    process->numFrames = (requestedSize + PHYSICAL_BLOCK_SIZE - 1) / PHYSICAL_BLOCK_SIZE;//向上取整

    process->frameQueue = (int *)malloc(process->numFrames * sizeof(int));
    process->frameQueueRear = 0;

    process->pageTable = (PageTableEntry *)malloc(PAGE_NUMBER * sizeof(PageTableEntry));
    process->pageSequence = (int *)malloc(process->numFrames * sizeof(int));
    process->pageSequenceSize = 0;

    process->pagesAccessed = 0;
    process->pageFaults = 0;

    // 初始化页表
    for (int i = 0; i < PAGE_NUMBER; i++) {
        process->pageTable[i].page_number = i;
        process->pageTable[i].frame_number = -1;
        process->pageTable[i].valid = false;
        process->pageTable[i].accessed = 0;
        process->pageTable[i].modified = false;
        process->pageTable[i].disk_address = 0;
    }

    // 根据全局分配策略分配物理块
    allocatePhysicalBlocksForProcess(process, process->numFrames);
}

//进程访问页面
void accessPage(Process *process, int pageNumber) {
    process->pagesAccessed++;

    // 检查页面是否在内存中
    if (!process->pageTable[pageNumber].valid) {
       // 判断是否需要动态分配额外的物理块
        if (ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT || 
            ALLOCATION_STRATEGY == VARIABLE_ALLOCATION_LOCAL_REPLACEMENT) {
            // 如果缺页次数超过阈值，则分配额外的物理块
            if (process->pageFaults >= dynamicThreshold) {
                process->numFrames++;
                //这里尝试分配，为了简化如果没有找到也不做任何处理
                for (int j = 0; j < TOTAL_PHYSICAL_BLOCKS; j++) {
                    if (physicalBlocks[j].processID < 0) {
                        physicalBlocks[j].isFree = true;
                        physicalBlocks[j].processID = process->processID;
                        process->frameQueue[process->frameQueueRear++] = j;
                        break;
                    }
                }
                dynamicThreshold += 5;
            }
        }
        // 调用分配算法为页面分配物理块
        allocatePhysicalBlockForPage(process, pageNumber);
    }
    else{
        //LRU 与 FIFO 算法的区别：LRU需要在访问页面的过程中一直维护队列
        if (REPLACEMENT_ALGORITHM == LRU_REPLACEMENT){
            updateLRU(process, pageNumber);
        }
    }
}