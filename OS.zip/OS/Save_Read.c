#include "os.h"
#include <stdio.h>

// 将进程信息保存到磁盘
void saveProcessInfoToDisk(Process *process, const char *filename) {
    FILE *file = fopen(filename, "wb"); // 二进制模式覆盖保存
    if (file == NULL) {
        return;
    }

    // 写入物理块表
    fwrite(physicalBlocks, sizeof(PhysicalBlock), TOTAL_PHYSICAL_BLOCKS, file);

    // 写入进程结构体
    fwrite(process, sizeof(Process), 1, file);

    // 写入进程的页表
    fwrite(process->pageTable, sizeof(PageTableEntry), PAGE_NUMBER, file);

    // 写入进程的页面访问序列
    fwrite(process->pageSequence, sizeof(int), process->pageSequenceSize, file);

    // 写入进程的物理块队列
    fwrite(process->frameQueue, sizeof(int), process->numFrames, file);

    fclose(file);
}

// 从磁盘读取进程信息
void loadProcessInfoFromDisk(Process *process, const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (file == NULL) {
        return;
    }

    // 读取物理块表
    fread(physicalBlocks, sizeof(PhysicalBlock), TOTAL_PHYSICAL_BLOCKS, file);

    // 读取进程结构体
    fread(process, sizeof(Process), 1, file);

    // 为进程的页表分配内存
    process->pageTable = (PageTableEntry *)malloc(PAGE_NUMBER * sizeof(PageTableEntry));
    if (process->pageTable == NULL) {
        fclose(file);
        return;
    }
    // 读取进程的页表
    fread(process->pageTable, sizeof(PageTableEntry), PAGE_NUMBER, file);

    // 为进程的页面访问序列分配内存
    process->pageSequence = (int *)malloc(process->pageSequenceSize * sizeof(int));
    if (process->pageSequence == NULL) {
        fclose(file);
        return;
    }
    // 读取进程的页面访问序列
    fread(process->pageSequence, sizeof(int), process->pageSequenceSize, file);

    // 为进程的物理块队列分配内存
    process->frameQueue = (int *)malloc(process->numFrames * sizeof(int));
    if (process->frameQueue == NULL) {
        fclose(file);
        return;
    }
    // 读取进程的物理块队列
    fread(process->frameQueue, sizeof(int), process->numFrames, file);

    fclose(file);
}