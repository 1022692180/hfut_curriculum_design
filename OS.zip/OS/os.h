#ifndef OS_H
#define OS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>

// 定义内存分配策略的枚举类型
         
typedef enum {
    FIXED_ALLOCATION_LOCAL_REPLACEMENT,  // 固定分配局部置换
    VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT,  // 可变分配全局置换
    VARIABLE_ALLOCATION_LOCAL_REPLACEMENT  // 可变分配局部置换
} AllocationStrategy;

// 定义页面局部置换算法的枚举类型
typedef enum {
    FIFO_REPLACEMENT,  // FIFO 置换算法
    LRU_REPLACEMENT    // LRU 置换算法
} ReplacementAlgorithm;

// 页内偏移是12位，页号是20位，逻辑地址是32位，即一共有4096个偏移位置，每个偏移位置对应一个字节，也就是页面大小是4KB

#define PAGE_SIZE 4096             // 页面的大小（4KB）
#define PHYSICAL_BLOCK_SIZE 4096   // 物理块大小（4KB）

// 内存空间大小（4MB）

#define TOTAL_PHYSICAL_BLOCKS 1024  // 物理块总数 = 内存空间大小 / 物理块大小 = 4MB / 4KB = 1024

//页表项大小为4B        

#define PAGE_NUMBER  4096   //页表长度

//页表大小 = 页表项数量（页面数量、页表长度）* 页表项大小 = 4096 * 4B = 16KB  
 
#define PAGE_OFFSET_MASK 0xFFF    // 页内偏移掩码

// 置换算法的宏定义
#define REPLACEMENT_ALGORITHM FIFO_REPLACEMENT

// 物理块分配算法策略的宏定义
#define ALLOCATION_STRATEGY VARIABLE_ALLOCATION_GLOBAL_REPLACEMENT

extern int dynamicThreshold; // 动态阈值

#define MAX_QUEUE_SIZE 100

// 全局静态的页面访问队列和进程ID队列
extern int *page_queue;
extern int *pid_queue;

extern int queue_size;     // 只需要使用一个数组下标遍历，保证页面访问队列和进程ID队列访问保持同步

// 物理块结构体
typedef struct {
    int blockNumber;       // 物理块编号
    uint32_t startAddress; // 物理块的起始地址
    bool isFree;           // 物理块是否空闲
    int processID;         // 物理块分配的进程ID
} PhysicalBlock;

extern PhysicalBlock *physicalBlocks;   //物理块表是一个全局变量，在initPhysicalBlocks()中完成初始化

// 请求页表结构体
typedef struct {
    int page_number;       // 页号
    int frame_number;      // 对应的物理块号
    bool valid;            // 页面是否在内存中
    int accessed;          // 页面访问次数
    bool modified;         // 页面是否被修改
    uint32_t disk_address; // 页面在磁盘上的地址
} PageTableEntry;

// 进程结构体
typedef struct {
    int processID;               // 进程 ID

    int numFrames;               // 分配的物理块数量
    
    int *frameQueue;             // 物理块队列，存储的是物理块号，根据头尾指针找到物理块的页面序列所在物理块在队列中的位置

    int frameQueueRear;          // 下一个要插入的物理块在物理块队列中的位置（数组下标）

    PageTableEntry *pageTable;   // 页表

    int *pageSequence;           // 页面访问序列
    int pageSequenceSize;        // 页面序列大小

    int pagesAccessed;           // 页面访问次数
    int pageFaults;              // 页面缺页次数
} Process;

#define MAX_PROCESS_SIZE 100
extern Process *process_queue[MAX_PROCESS_SIZE];// 进程队列
extern int process_size;

// 初始化全局页面访问队列和进程ID队列
void initGlobalQueues();

// 释放全局页面访问队列和进程ID队列
void freeGlobalQueues();

// 初始化进程队列
void initProcessQueue();

// 释放进程队列
void freeProcessQueue();

// FIFO 和 LRU 算法局部置换算法
void Local_Replace(Process *process, int pageNumber);

// 全局置换算法
void Global_Replace(Process *process, int pageNumber);

// 维护LRU队列
void updateLRU(Process *process, int pageNumber);

// 初始化物理块表
void initPhysicalBlocks();

// 释放分配的物理块表
void freePhysicalBlocks();

// 为进程创建的时候分配一定数量的物理块
void allocatePhysicalBlocksForProcess(Process *process, int numBlocks);

// 页面访问时为页面分配物理块的函数
void allocatePhysicalBlockForPage(Process *process, int pageNumber);

// 创建进程：进程号 进程申请的内存空间大小
void createProcess(Process* process, int processID, int requestedSize);

//进程访问页面
void accessPage(Process* process, int pageNumber);

// 提取页号
int extractPage(uint32_t logicalAddress);

//提取页内偏移量
int extractOffset(uint32_t logicalAddress);

// 将进程信息保存到磁盘
void saveProcessInfoToDisk(Process *process, const char *filename);

// 从磁盘读取进程信息
void loadProcessInfoFromDisk(Process *process, const char *filename);

#endif